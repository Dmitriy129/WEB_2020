module.exports = {
    env: {
        customKey: 'my-value',
        GIT_CLIENT_ID: "7459031a7b558dcdc076",
        GIT_CLIENT_SECRET: "1be85c04854b3912450dd984459cf65173ed3f3d",
        GIT_REDIRECT_URL: "http://localhost:3000/auth",
    },
}