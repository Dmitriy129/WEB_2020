
      /* This cache is used by webpack for instantiated modules */
      module.exports = {}
      