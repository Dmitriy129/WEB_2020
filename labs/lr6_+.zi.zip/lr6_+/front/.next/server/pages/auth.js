module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/auth/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/Auth/index.js":
/*!**********************************!*\
  !*** ./components/Auth/index.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ \"@material-ui/core\");\n/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! mobx-react */ \"mobx-react\");\n/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! clsx */ \"clsx\");\n/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_5__);\n\nvar _jsxFileName = \"/Users/fox1209/Documents/#university/WEB_2020/labs/lr6_+/front/components/Auth/index.js\";\n\n\n\n\n\nconst useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__[\"makeStyles\"])(theme => ({\n  pre: {\n    width: \"100vw\",\n    height: \"100vh\",\n    // backgroundImage: \"url(/img/github-logo.svg)\",\n    backgroundRepeat: \"no-repeat\",\n    backgroundPosition: \"center\"\n  },\n  loader: {\n    top: \"51% !important\"\n  },\n  center: {\n    margin: \"auto\",\n    width: \"fit-content\",\n    height: \"fit-content\",\n    position: \"absolute\",\n    top: \"50%\",\n    bottom: \"50%\",\n    left: \"0%\",\n    right: \"0%\"\n  },\n  github: {\n    border: \"1px solid black\",\n    borderRadius: theme.spacing(1),\n    color: \"black\",\n    padding: theme.spacing(2),\n    zIndex: 2,\n    overflow: \"hidden\",\n    textDecoration: \"none\",\n    textAlign: \"center\",\n    display: \"table\",\n    transition: \"0.25s\"\n  },\n  octocat: {\n    height: 30,\n    transition: \"0.25s\"\n  }\n}));\n\nconst AuthManager = props => {\n  const {\n    signIn\n  } = props.me;\n  const classes = useStyles();\n  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__[\"useRouter\"])();\n  const {\n    0: tryingSignIn,\n    1: setTryingSignIn\n  } = Object(react__WEBPACK_IMPORTED_MODULE_1__[\"useState\"])(true);\n  Object(react__WEBPACK_IMPORTED_MODULE_1__[\"useEffect\"])(() => {\n    if (router.query.code) {\n      setTryingSignIn(true);\n      signIn(router.query.code).then(user => router.push(\"/\")).catch(error => {\n        alert(\"пока входить не надо\");\n      }).then(() => setTryingSignIn(false));\n    } else setTryingSignIn(false);\n  }, [router]);\n  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(\"div\", {\n    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(\"div\", {\n      className: classes.pre,\n      children: tryingSignIn ? \"Попытка входа\" : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(\"a\", {\n        href: `https://github.com/login/oauth/authorize?response_type=code&client_id=${\"7459031a7b558dcdc076\"}&redirect_uri=${\"http://localhost:3000/auth\"}`,\n        className: clsx__WEBPACK_IMPORTED_MODULE_5___default()(classes.github, classes.center),\n        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(\"span\", {\n          children: \"\\u0412\\u0445\\u043E\\u0434 \\u0447\\u0435\\u0440\\u0435\\u0437 GitHub\"\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 79,\n          columnNumber: 25\n        }, undefined)\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 75,\n        columnNumber: 23\n      }, undefined)\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 72,\n      columnNumber: 13\n    }, undefined)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 69,\n    columnNumber: 9\n  }, undefined);\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__[\"inject\"])('me')(Object(mobx_react__WEBPACK_IMPORTED_MODULE_4__[\"observer\"])(AuthManager)));//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0F1dGgvaW5kZXguanM/NjA0NCJdLCJuYW1lcyI6WyJ1c2VTdHlsZXMiLCJtYWtlU3R5bGVzIiwidGhlbWUiLCJwcmUiLCJ3aWR0aCIsImhlaWdodCIsImJhY2tncm91bmRSZXBlYXQiLCJiYWNrZ3JvdW5kUG9zaXRpb24iLCJsb2FkZXIiLCJ0b3AiLCJjZW50ZXIiLCJtYXJnaW4iLCJwb3NpdGlvbiIsImJvdHRvbSIsImxlZnQiLCJyaWdodCIsImdpdGh1YiIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsInNwYWNpbmciLCJjb2xvciIsInBhZGRpbmciLCJ6SW5kZXgiLCJvdmVyZmxvdyIsInRleHREZWNvcmF0aW9uIiwidGV4dEFsaWduIiwiZGlzcGxheSIsInRyYW5zaXRpb24iLCJvY3RvY2F0IiwiQXV0aE1hbmFnZXIiLCJwcm9wcyIsInNpZ25JbiIsIm1lIiwiY2xhc3NlcyIsInJvdXRlciIsInVzZVJvdXRlciIsInRyeWluZ1NpZ25JbiIsInNldFRyeWluZ1NpZ25JbiIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwicXVlcnkiLCJjb2RlIiwidGhlbiIsInVzZXIiLCJwdXNoIiwiY2F0Y2giLCJlcnJvciIsImFsZXJ0IiwicHJvY2VzcyIsImNsc3giLCJpbmplY3QiLCJvYnNlcnZlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBLE1BQU1BLFNBQVMsR0FBR0Msb0VBQVUsQ0FBQ0MsS0FBSyxLQUFLO0FBQ25DQyxLQUFHLEVBQUU7QUFDREMsU0FBSyxFQUFFLE9BRE47QUFFREMsVUFBTSxFQUFFLE9BRlA7QUFHRDtBQUNBQyxvQkFBZ0IsRUFBRSxXQUpqQjtBQUtEQyxzQkFBa0IsRUFBRTtBQUxuQixHQUQ4QjtBQVFuQ0MsUUFBTSxFQUFFO0FBQ0pDLE9BQUcsRUFBRTtBQURELEdBUjJCO0FBV25DQyxRQUFNLEVBQUU7QUFDSkMsVUFBTSxFQUFFLE1BREo7QUFFSlAsU0FBSyxFQUFFLGFBRkg7QUFHSkMsVUFBTSxFQUFFLGFBSEo7QUFJSk8sWUFBUSxFQUFFLFVBSk47QUFLSkgsT0FBRyxFQUFFLEtBTEQ7QUFNSkksVUFBTSxFQUFFLEtBTko7QUFPSkMsUUFBSSxFQUFFLElBUEY7QUFRSkMsU0FBSyxFQUFFO0FBUkgsR0FYMkI7QUFxQm5DQyxRQUFNLEVBQUU7QUFDSkMsVUFBTSxFQUFFLGlCQURKO0FBRUpDLGdCQUFZLEVBQUVoQixLQUFLLENBQUNpQixPQUFOLENBQWMsQ0FBZCxDQUZWO0FBR0pDLFNBQUssRUFBRSxPQUhIO0FBSUpDLFdBQU8sRUFBRW5CLEtBQUssQ0FBQ2lCLE9BQU4sQ0FBYyxDQUFkLENBSkw7QUFNSkcsVUFBTSxFQUFFLENBTko7QUFPSkMsWUFBUSxFQUFFLFFBUE47QUFRSkMsa0JBQWMsRUFBRSxNQVJaO0FBU0pDLGFBQVMsRUFBRSxRQVRQO0FBVUpDLFdBQU8sRUFBRSxPQVZMO0FBV0pDLGNBQVUsRUFBRTtBQVhSLEdBckIyQjtBQWtDbkNDLFNBQU8sRUFBRTtBQUNMdkIsVUFBTSxFQUFFLEVBREg7QUFFTHNCLGNBQVUsRUFBRTtBQUZQO0FBbEMwQixDQUFMLENBQU4sQ0FBNUI7O0FBMENBLE1BQU1FLFdBQVcsR0FBSUMsS0FBRCxJQUFXO0FBQzNCLFFBQU07QUFBRUM7QUFBRixNQUFhRCxLQUFLLENBQUNFLEVBQXpCO0FBQ0EsUUFBTUMsT0FBTyxHQUFHakMsU0FBUyxFQUF6QjtBQUNBLFFBQU1rQyxNQUFNLEdBQUdDLDZEQUFTLEVBQXhCO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLFlBQUQ7QUFBQSxPQUFlQztBQUFmLE1BQWtDQyxzREFBUSxDQUFDLElBQUQsQ0FBaEQ7QUFDQUMseURBQVMsQ0FBQyxNQUFNO0FBQ1osUUFBSUwsTUFBTSxDQUFDTSxLQUFQLENBQWFDLElBQWpCLEVBQXVCO0FBQ25CSixxQkFBZSxDQUFDLElBQUQsQ0FBZjtBQUNBTixZQUFNLENBQUNHLE1BQU0sQ0FBQ00sS0FBUCxDQUFhQyxJQUFkLENBQU4sQ0FDS0MsSUFETCxDQUNXQyxJQUFELElBQVVULE1BQU0sQ0FBQ1UsSUFBUCxDQUFZLEdBQVosQ0FEcEIsRUFFS0MsS0FGTCxDQUVZQyxLQUFELElBQVc7QUFDZEMsYUFBSyxDQUFDLHNCQUFELENBQUw7QUFDSCxPQUpMLEVBS0tMLElBTEwsQ0FLVSxNQUFNTCxlQUFlLENBQUMsS0FBRCxDQUwvQjtBQU1ILEtBUkQsTUFTS0EsZUFBZSxDQUFDLEtBQUQsQ0FBZjtBQUNSLEdBWFEsRUFXTixDQUFDSCxNQUFELENBWE0sQ0FBVDtBQWFBLHNCQUNJO0FBQUEsMkJBR0k7QUFBSyxlQUFTLEVBQUVELE9BQU8sQ0FBQzlCLEdBQXhCO0FBQUEsZ0JBQ0tpQyxZQUFZLEdBQ1AsZUFETyxnQkFFUDtBQUNFLFlBQUksRUFBRyx5RUFBd0VZLHNCQUEwQixpQkFBZ0JBLDRCQUE2QixFQUR4SjtBQUVFLGlCQUFTLEVBQUVDLDJDQUFJLENBQUNoQixPQUFPLENBQUNqQixNQUFULEVBQWlCaUIsT0FBTyxDQUFDdkIsTUFBekIsQ0FGakI7QUFBQSwrQkFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBaUJILENBbkNEOztBQXFDZXdDLHdIQUFNLENBQUMsSUFBRCxDQUFOLENBQWFDLDJEQUFRLENBQUN0QixXQUFELENBQXJCLENBQWYiLCJmaWxlIjoiLi9jb21wb25lbnRzL0F1dGgvaW5kZXguanMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQ2lyY3VsYXJQcm9ncmVzcywgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJ1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXG5pbXBvcnQgeyBvYnNlcnZlciwgaW5qZWN0IH0gZnJvbSAnbW9ieC1yZWFjdCc7XG5pbXBvcnQgY2xzeCBmcm9tICdjbHN4J1xuXG5cbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXModGhlbWUgPT4gKHtcbiAgICBwcmU6IHtcbiAgICAgICAgd2lkdGg6IFwiMTAwdndcIixcbiAgICAgICAgaGVpZ2h0OiBcIjEwMHZoXCIsXG4gICAgICAgIC8vIGJhY2tncm91bmRJbWFnZTogXCJ1cmwoL2ltZy9naXRodWItbG9nby5zdmcpXCIsXG4gICAgICAgIGJhY2tncm91bmRSZXBlYXQ6IFwibm8tcmVwZWF0XCIsXG4gICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogXCJjZW50ZXJcIixcbiAgICB9LFxuICAgIGxvYWRlcjoge1xuICAgICAgICB0b3A6IFwiNTElICFpbXBvcnRhbnRcIixcbiAgICB9LFxuICAgIGNlbnRlcjoge1xuICAgICAgICBtYXJnaW46IFwiYXV0b1wiLFxuICAgICAgICB3aWR0aDogXCJmaXQtY29udGVudFwiLFxuICAgICAgICBoZWlnaHQ6IFwiZml0LWNvbnRlbnRcIixcbiAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgdG9wOiBcIjUwJVwiLFxuICAgICAgICBib3R0b206IFwiNTAlXCIsXG4gICAgICAgIGxlZnQ6IFwiMCVcIixcbiAgICAgICAgcmlnaHQ6IFwiMCVcIixcbiAgICB9LFxuICAgIGdpdGh1Yjoge1xuICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIGJsYWNrXCIsXG4gICAgICAgIGJvcmRlclJhZGl1czogdGhlbWUuc3BhY2luZygxKSxcbiAgICAgICAgY29sb3I6IFwiYmxhY2tcIixcbiAgICAgICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcblxuICAgICAgICB6SW5kZXg6IDIsXG4gICAgICAgIG92ZXJmbG93OiBcImhpZGRlblwiLFxuICAgICAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXG4gICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcbiAgICAgICAgZGlzcGxheTogXCJ0YWJsZVwiLFxuICAgICAgICB0cmFuc2l0aW9uOiBcIjAuMjVzXCIsXG4gICAgfSxcbiAgICBvY3RvY2F0OiB7XG4gICAgICAgIGhlaWdodDogMzAsXG4gICAgICAgIHRyYW5zaXRpb246IFwiMC4yNXNcIixcbiAgICB9XG5cbn0pKVxuXG5cbmNvbnN0IEF1dGhNYW5hZ2VyID0gKHByb3BzKSA9PiB7XG4gICAgY29uc3QgeyBzaWduSW4gfSA9IHByb3BzLm1lXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgICBjb25zdCBbdHJ5aW5nU2lnbkluLCBzZXRUcnlpbmdTaWduSW5dID0gdXNlU3RhdGUodHJ1ZSlcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocm91dGVyLnF1ZXJ5LmNvZGUpIHtcbiAgICAgICAgICAgIHNldFRyeWluZ1NpZ25Jbih0cnVlKVxuICAgICAgICAgICAgc2lnbkluKHJvdXRlci5xdWVyeS5jb2RlKVxuICAgICAgICAgICAgICAgIC50aGVuKCh1c2VyKSA9PiByb3V0ZXIucHVzaChcIi9cIikpXG4gICAgICAgICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBhbGVydChcItC/0L7QutCwINCy0YXQvtC00LjRgtGMINC90LUg0L3QsNC00L5cIilcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHNldFRyeWluZ1NpZ25JbihmYWxzZSkpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBzZXRUcnlpbmdTaWduSW4oZmFsc2UpXG4gICAgfSwgW3JvdXRlcl0pO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIHsvKiA8cD5hdXRoIHdvcmtzITwvcD4gKi99XG4gICAgICAgICAgICB7Lyoge3Byb2Nlc3MuZW52LkdJVF9SRURJUkVDVF9VUkx9ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMucHJlfT5cbiAgICAgICAgICAgICAgICB7dHJ5aW5nU2lnbkluXG4gICAgICAgICAgICAgICAgICAgID8gXCLQn9C+0L/Ri9GC0LrQsCDQstGF0L7QtNCwXCJcbiAgICAgICAgICAgICAgICAgICAgOiA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17YGh0dHBzOi8vZ2l0aHViLmNvbS9sb2dpbi9vYXV0aC9hdXRob3JpemU/cmVzcG9uc2VfdHlwZT1jb2RlJmNsaWVudF9pZD0ke3Byb2Nlc3MuZW52LkdJVF9DTElFTlRfSUR9JnJlZGlyZWN0X3VyaT0ke3Byb2Nlc3MuZW52LkdJVF9SRURJUkVDVF9VUkx9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xzeChjbGFzc2VzLmdpdGh1YiwgY2xhc3Nlcy5jZW50ZXIpfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7QktGF0L7QtCDRh9C10YDQtdC3IEdpdEh1Yjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IGluamVjdCgnbWUnKShvYnNlcnZlcihBdXRoTWFuYWdlcikpXG5cbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/Auth/index.js\n");

/***/ }),

/***/ "./pages/auth/index.js":
/*!*****************************!*\
  !*** ./pages/auth/index.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_Auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/Auth */ \"./components/Auth/index.js\");\n\nvar _jsxFileName = \"/Users/fox1209/Documents/#university/WEB_2020/labs/lr6_+/front/pages/auth/index.js\";\n\n\n\nconst index = () => {\n  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__[\"jsxDEV\"])(_components_Auth__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 7,\n    columnNumber: 9\n  }, undefined);\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (index);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9hdXRoL2luZGV4LmpzPzZjNTUiXSwibmFtZXMiOlsiaW5kZXgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUE7QUFDQTs7QUFHQSxNQUFNQSxLQUFLLEdBQUcsTUFBTTtBQUNoQixzQkFDSSxxRUFBQyx3REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFHSCxDQUpEOztBQU1lQSxvRUFBZiIsImZpbGUiOiIuL3BhZ2VzL2F1dGgvaW5kZXguanMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgQXV0aCBmcm9tICcuLi8uLi9jb21wb25lbnRzL0F1dGgnXG5cblxuY29uc3QgaW5kZXggPSAoKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPEF1dGggLz5cbiAgICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IGluZGV4XG4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/auth/index.js\n");

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"@material-ui/core\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZVwiP2I2OTkiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEiLCJmaWxlIjoiQG1hdGVyaWFsLXVpL2NvcmUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///@material-ui/core\n");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"clsx\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJjbHN4XCI/N2I0OCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSIsImZpbGUiOiJjbHN4LmpzIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiY2xzeFwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///clsx\n");

/***/ }),

/***/ "mobx-react":
/*!*****************************!*\
  !*** external "mobx-react" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"mobx-react\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJtb2J4LXJlYWN0XCI/NWJjYSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSIsImZpbGUiOiJtb2J4LXJlYWN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibW9ieC1yZWFjdFwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///mobx-react\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"next/router\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L3JvdXRlclwiP2Q4M2UiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEiLCJmaWxlIjoibmV4dC9yb3V0ZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L3JvdXRlclwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///next/router\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"react\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiPzU4OGUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEiLCJmaWxlIjoicmVhY3QuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///react\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"react/jsx-dev-runtime\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIj9jZDkwIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBIiwiZmlsZSI6InJlYWN0L2pzeC1kZXYtcnVudGltZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///react/jsx-dev-runtime\n");

/***/ })

/******/ });