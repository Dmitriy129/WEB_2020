import React from 'react'
import Auth from '../../components/Auth'


const index = () => {
    return (
        <Auth />
    )
}

export default index
