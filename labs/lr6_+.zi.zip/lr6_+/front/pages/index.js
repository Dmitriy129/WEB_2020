import Head from 'next/head'
import WithBar from '../components/Bar/WithBar'

export default function Home() {
  return (
    <WithBar >
      тут пусто, но на других вкладнах нет
    </WithBar>
  )
}
