var man = {
    name="aa",
    surname="bb",
    fun1 = function name(params) {

    }
}