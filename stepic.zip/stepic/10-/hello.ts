import { Component } from "@angular/core";

@Component({
  selector: "my-hello",
  template: ``,
  styles: [``]
})
export class HelloComponent {
  name = "hello";
}
