$("h3")
    .toArray()
    .map(elem => (elem.innerHTML = "TEST"));
$("#li1")[0].innerHTML = "ODD";
$("#li2")[0].innerHTML = "EVEN";