class Calculator {
  x: number;
  constructor(xx: number) {
    this.x = xx;
  }
  add(y: number) {
    return this.x + y;
  }
}
